Library to control Dream Media Dreambox.
Tested on DM800 HD se
Please let me know if it works on other models too
